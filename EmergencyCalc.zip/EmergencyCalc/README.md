# EmergencyCalc
Emergency calculator for students in need.
